#include "cfmainwindow.h"
#include "ui_cfmainwindow.h"
#include "configuration.h"
#include "fixedmainwindow.h"
#include "QMdiSubWindow"

CFMainWindow::CFMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::CFMainWindow)
{
    ui->setupUi(this);
    setCentralWidget(ui->mdiArea);
    loadSubWindow(new Configuration(this));
}

CFMainWindow::~CFMainWindow()
{
    delete ui;
}
void CFMainWindow::loadSubWindow(QWidget *widget)
{
    auto window = ui->mdiArea->addSubWindow(widget);
    window->setWindowIcon(QPixmap(":icon/icon/FPT_T.png"));
    window->setWindowTitle("Configuration");
    window->showMaximized();
}

void CFMainWindow::on_action_New_triggered()
{
    loadSubWindow(new FixedMainWindow(this));
}
