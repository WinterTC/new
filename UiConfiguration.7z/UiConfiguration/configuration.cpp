#include "configuration.h"
#include "ui_configuration.h"

Configuration::Configuration(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Configuration)
{
    ui->setupUi(this);

    Widget = new QWidget(this);
    G_Layout = new QGridLayout;

    H1_Layout = new QHBoxLayout;
    ButtonBoard = new QPushButton("Board");
    ButtonBoard->setFixedSize(70,50);
    ButtonBoard->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonconnetB1 = new QPushButton;
    ButtonconnetB1->setStyleSheet("background-color: rgb(82, 105, 255)");
    ButtonconnetB1->setFixedSize(20,20);
    H1_Layout->addWidget(ButtonBoard);
    H1_Layout->addWidget(ButtonconnetB1);

    H2_Layout = new QHBoxLayout;
    Buttonconnet2 = new QPushButton;
    Buttonconnet2->setStyleSheet("background-color: rgb(82, 105, 255)");
    Buttonconnet2->setFixedSize(20,20);
    H2_Layout->addWidget(Buttonconnet2);

    QVBoxLayout *VB3_Layout = new QVBoxLayout;

    V3_Layout = new QVBoxLayout;
    ButtonconnetM3 = new QPushButton;
    ButtonconnetM3->setStyleSheet("background-color: rgb(82, 105, 255)");
    ButtonconnetM3->setFixedSize(20,20);
    V3_Layout->addWidget(ButtonconnetM3);

    ButtonMessage = new QPushButton("Mess");
    ButtonMessage->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonMessage->setFixedSize(55,55);

    VB3_Layout->addLayout(V3_Layout,2);
    VB3_Layout->addWidget(ButtonMessage);


    QHBoxLayout *H4 = new QHBoxLayout;
    H4_Layout= new QHBoxLayout;
    ButtonStatic = new QPushButton("Static");
    ButtonStatic->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonStatic->setFixedSize(90,50);
    ButtonconnetS4 = new QPushButton;
    ButtonconnetS4->setStyleSheet("background-color: rgb(82, 105, 255)");
    ButtonconnetS4->setFixedSize(20,20);
    H4_Layout->addWidget(ButtonconnetS4);
    H4->addLayout(H4_Layout,0);
    H4->addWidget(ButtonStatic,5);

    QHBoxLayout *H5 = new QHBoxLayout;
    H5_Layout= new QHBoxLayout;
    ButtonTrace = new QPushButton("Trace");
    ButtonTrace->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonTrace->setFixedSize(90,50);
    ButtonconnetT5 = new QPushButton;
    ButtonconnetT5->setStyleSheet("background-color: rgb(82, 105, 255)");
    ButtonconnetT5->setFixedSize(20,20);
    H5_Layout->addWidget(ButtonconnetT5);
    H5->addLayout(H5_Layout,0);
    H5->addWidget(ButtonTrace,5);

    QHBoxLayout *H6 = new QHBoxLayout;
    H6_Layout= new QHBoxLayout;
    ButtonData = new QPushButton("Data");
    ButtonData->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonData->setFixedSize(90,50);
    ButtonconnetD6 = new QPushButton;
    ButtonconnetD6->setStyleSheet("background-color: rgb(82, 105, 255)");
    ButtonconnetD6->setFixedSize(20,20);
    H6_Layout->addWidget(ButtonconnetD6);
    H6->addLayout(H6_Layout,0);
    H6->addWidget(ButtonData,5);

    QHBoxLayout *H7 = new QHBoxLayout;
    H7_Layout= new QHBoxLayout;
    ButtonLogging = new QPushButton("Logging");
    ButtonLogging->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonLogging->setFixedSize(90,50);
    ButtonconnetL7 = new QPushButton;
    ButtonconnetL7->setStyleSheet("background-color: rgb(82, 105, 255)");
    ButtonconnetL7->setFixedSize(20,20);
    H7_Layout->addWidget(ButtonconnetL7);
    H7->addLayout(H7_Layout,0);
    H7->addWidget(ButtonLogging,5);

    QHBoxLayout *H8 = new QHBoxLayout;
    H8_Layout= new QHBoxLayout;
    ButtonGraphics = new QPushButton("Graphics");
    ButtonGraphics->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonGraphics->setFixedSize(90,50);
    ButtonconnetG8 = new QPushButton;
    ButtonconnetG8->setStyleSheet("background-color: rgb(82, 105, 255)");
    ButtonconnetG8->setFixedSize(20,20);
    H8_Layout->addWidget(ButtonconnetG8);
    H8->addLayout(H8_Layout,0);
    H8->addWidget(ButtonGraphics,5);


    V_Layout= new QVBoxLayout;
    V_Layout->addLayout(H4);
    V_Layout->addLayout(H5);
    V_Layout->addLayout(H6);
    V_Layout->addLayout(H7);
    V_Layout->addLayout(H8);

    G_Layout->addLayout(H1_Layout,0,0,2,1);
    G_Layout->addLayout(VB3_Layout,1,1,2,1);
    G_Layout->addLayout(H2_Layout,0,2,2,1);
    G_Layout->addLayout(V_Layout,0,3,2,1);


    ButtonStatic->setContextMenuPolicy(Qt::CustomContextMenu);
    ButtonData->setContextMenuPolicy(Qt::CustomContextMenu);
    ButtonTrace->setContextMenuPolicy(Qt::CustomContextMenu);
    ButtonLogging->setContextMenuPolicy(Qt::CustomContextMenu);
    ButtonGraphics->setContextMenuPolicy(Qt::CustomContextMenu);

    connect(ButtonStatic,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuStatic(QPoint)));
    connect(ButtonData,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuData(QPoint)));
    connect(ButtonTrace,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuTrace(QPoint)));
    connect(ButtonLogging,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuLogging(QPoint)));
    connect(ButtonGraphics,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuGraphics(QPoint)));

    Buttonconnet2->setContextMenuPolicy(Qt::CustomContextMenu);
    ButtonconnetB1->setContextMenuPolicy(Qt::CustomContextMenu);
    ButtonconnetS4->setContextMenuPolicy(Qt::CustomContextMenu);
    ButtonconnetD6->setContextMenuPolicy(Qt::CustomContextMenu);
    ButtonconnetT5->setContextMenuPolicy(Qt::CustomContextMenu);
    ButtonconnetG8->setContextMenuPolicy(Qt::CustomContextMenu);
    ButtonconnetL7->setContextMenuPolicy(Qt::CustomContextMenu);
    ButtonconnetM3->setContextMenuPolicy(Qt::CustomContextMenu);

    connect(Buttonconnet2,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuConnect(QPoint)));
    connect(ButtonconnetB1,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconBoard(QPoint)));
    connect(ButtonconnetM3,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuMessage(QPoint)));
    connect(ButtonconnetS4,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconStatic(QPoint)));
    connect(ButtonconnetT5,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconTrace(QPoint)));
    connect(ButtonconnetD6,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconData(QPoint)));
    connect(ButtonconnetL7,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconLogging(QPoint)));
    connect(ButtonconnetG8,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconGraphics(QPoint)));



    Widget->setLayout(G_Layout);
    setCentralWidget(Widget);

}

Configuration::~Configuration()
{
    delete ui;
}

void Configuration::paintEvent(QPaintEvent *event)
{

    QPainter Painter(this);
    QPen Linepen(Qt::gray);
    Linepen.setWidth(2);
    Painter.setPen(Linepen);

    QPoint PB(ButtonBoard->x()+ButtonBoard->width()/2,ButtonBoard->y()+ButtonBoard->height()/2);
    QPoint P2(ButtonconnetB1->x()+ButtonconnetB1->width()/2,ButtonconnetB1->y()+ ButtonconnetB1->height()/2);
    QPoint P3(Buttonconnet2->x()+Buttonconnet2->width()/2,Buttonconnet2->y()+Buttonconnet2->height()/2);
    QPoint P4(ButtonconnetD6->x()+ButtonconnetD6->width()/2,ButtonconnetD6->y()+ButtonconnetD6->height()/2);
    QPoint P5(ButtonData->x()+ButtonData->width()/2,ButtonData->y()+ButtonData->height()/2);
    QPoint P23((P2+P3)/2);
   // QPoint P6(ButtonconnetM3->x()+ButtonconnetM3->width()/2,ButtonconnetM3->y()++ ButtonconnetM3->height()/2);
    QPoint PM(ButtonMessage->x()+ButtonMessage->width()/2,ButtonMessage->y()+ButtonMessage->height()/2);

    QPoint PM1(ButtonMessage->x()+ButtonMessage->width()/2,ButtonMessage->y()+ButtonMessage->height()/2);

    QPoint PB1(ButtonBoard->x()+ButtonBoard->width()/2,ButtonBoard->y()+ButtonBoard->height()/2);

    QPoint PCS(ButtonconnetS4->x()-20+ButtonconnetS4->width()/2,ButtonconnetS4->y()+ ButtonconnetS4->height()/2);
    QPoint PCT(ButtonconnetT5->x()-20+ButtonconnetT5->width()/2,ButtonconnetT5->y()+ ButtonconnetT5->height()/2);
    QPoint PCD(ButtonconnetD6->x()-20+ButtonconnetD6->width()/2,ButtonconnetD6->y()+ ButtonconnetD6->height()/2);
    QPoint PCL(ButtonconnetL7->x()-20+ButtonconnetL7->width()/2,ButtonconnetL7->y()+ ButtonconnetL7->height()/2);
    QPoint PCG(ButtonconnetG8->x()-20+ButtonconnetG8->width()/2,ButtonconnetG8->y()+ ButtonconnetG8->height()/2);


    QPoint PS(ButtonStatic->x()+ButtonStatic->width()/2,ButtonStatic->y()+ButtonStatic->height()/2);
    QPoint PT(ButtonTrace->x()+ButtonTrace->width()/2,ButtonTrace->y()+ ButtonTrace->height()/2);
    QPoint PD(ButtonData->x()+ButtonData->width()/2,ButtonData->y()+ ButtonData->height()/2);
    QPoint PL(ButtonLogging->x()+ButtonLogging->width()/2,ButtonLogging->y()+ ButtonLogging->height()/2);
    QPoint PG(ButtonGraphics->x()+ButtonGraphics->width()/2,ButtonGraphics->y()+ ButtonGraphics->height()/2);

    //QPoint PP(ButtonP->x()+ButtonP->width()/2,ButtonP->y()++ButtonP->height()/2);
    //QPoint PCN1(ButtonCN1->x()+ButtonCN1->width()/2,ButtonCN1->y()++ButtonCN1->height()/2);
    //Painter.drawLine(,PCN1);


    Painter.drawLine(PCS,PCT);
    Painter.drawLine(PCD,PCT);
    Painter.drawLine(PCD,PCL);
    Painter.drawLine(PCG,PCL);

    Painter.drawLine(PCS,PS);
    Painter.drawLine(PCD,PD);
    Painter.drawLine(PCT,PT);
    Painter.drawLine(PCL,PL);
    Painter.drawLine(PCG,PG);

    Painter.drawLine(PB,P2);
    Painter.drawLine(P2,P3);
    Painter.drawLine(P23,PM);

    Painter.drawLine(PM,PM1);

    Painter.drawLine(PB,PB1);
    Painter.drawLine(PB1,PM1);

    Painter.drawLine(P3,P4);
    Painter.drawLine(P4,P5);

    event->accept();
}

void Configuration::contextMenuConnect(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertP = ShowMenu->addAction("Insert_P");
    InsertPF = ShowMenu->addAction("Insert_PF");
    InsertR = ShowMenu->addAction("Insert_R");

    ShowMenu->popup(Buttonconnet2->mapToGlobal(point));

    connect(InsertP,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPS()));
    connect(InsertPF,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPF()));
    connect(InsertR,SIGNAL(triggered(bool)),this,SLOT(ClickInsertR()));
}

void Configuration::contextMenuStatic(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertStaticWindow = ShowMenu->addAction("InSert &Static Window");
    InsertTraceWindow = ShowMenu->addAction("InSert &Trace Window");
    InsertDataWindow = ShowMenu->addAction("InSert &Data Window");
    InsertLoggingWindow = ShowMenu->addAction("InSert &Logging Window");
    InsertGraphicsWindow = ShowMenu->addAction("InSert &Graphics Window");


    QPoint globalPos_1 = ButtonStatic->mapFromGlobal(point);
    ShowMenu->popup(globalPos_1);
    ShowMenu->popup(ButtonStatic->mapToGlobal(point));

    ShowMenu->addSeparator();
    Remove = ShowMenu->addAction("Remove");

    connect(InsertStaticWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonStatic()));
    connect(InsertTraceWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonTrace()));
    connect(InsertDataWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonData()));
    connect(InsertLoggingWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonLog()));
    connect(InsertGraphicsWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonGraphics()));
    connect(Remove,SIGNAL(triggered()),this,SLOT(ClickRemove()));

    //ShowMenu->popup(mapFromGlobal(point));
}

void Configuration::contextMenuStatici(const QPoint &point)
{
    static int i = 0;
    ShowMenu = new QMenu(this);
    InsertStaticWindow = ShowMenu->addAction("InSert Static Window");
    InsertTraceWindow = ShowMenu->addAction("InSert Trace Window");
    InsertDataWindow = ShowMenu->addAction("InSert Data Window");
    InsertLoggingWindow = ShowMenu->addAction("InSert Logging Window");
    InsertGraphicsWindow = ShowMenu->addAction("InSert Graphics Window");

    QPoint globalPos_i = Button[i]->mapToGlobal(point);
    ShowMenu->popup(globalPos_i);
    ShowMenu->popup(Button[i]->mapToGlobal(point));

    ShowMenu->addSeparator();
    Remove = ShowMenu->addAction("Remove");

    connect(InsertStaticWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonStatic()));
    connect(InsertTraceWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonTrace()));
    connect(InsertDataWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonData()));
    connect(InsertLoggingWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonLog()));
    connect(InsertGraphicsWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonGraphics()));
    connect(Remove,SIGNAL(triggered()),this,SLOT(ClickRemove()));
    i++;
}

void Configuration::contextMenuTrace(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertStaticWindow = ShowMenu->addAction("InSert Static Window");
    InsertTraceWindow = ShowMenu->addAction("InSert Trace Window");
    InsertDataWindow = ShowMenu->addAction("InSert Data Window");
    InsertLoggingWindow = ShowMenu->addAction("InSert Logging Window");
    InsertGraphicsWindow = ShowMenu->addAction("InSert Graphics Window");

    QPoint globalPos_3 = ButtonTrace->mapToGlobal(point);
    ShowMenu->popup(globalPos_3);
    ShowMenu->popup(ButtonTrace->mapToGlobal(point));

    ShowMenu->addSeparator();
    Remove = ShowMenu->addAction("Remove");

    connect(InsertStaticWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonStatic()));
    connect(InsertTraceWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonTrace()));
    connect(InsertDataWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonData()));
    connect(InsertLoggingWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonLog()));
    connect(InsertGraphicsWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonGraphics()));
    connect(Remove,SIGNAL(triggered()),this,SLOT(ClickRemove()));
}

void Configuration::contextMenuTracei(const QPoint &point)
{
    static int i = 0;
    ShowMenu = new QMenu(this);
    InsertStaticWindow = ShowMenu->addAction("InSert Static Window");
    InsertTraceWindow = ShowMenu->addAction("InSert Trace Window");
    InsertDataWindow = ShowMenu->addAction("InSert Data Window");
    InsertLoggingWindow = ShowMenu->addAction("InSert Logging Window");
    InsertGraphicsWindow = ShowMenu->addAction("InSert Graphics Window");

    QPoint globalPos_i = Button[i]->mapToGlobal(point);
    ShowMenu->popup(globalPos_i);
    ShowMenu->popup(Button[i]->mapToGlobal(point));

    ShowMenu->addSeparator();
    Remove = ShowMenu->addAction("Remove");

    connect(InsertStaticWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonStatic()));
    connect(InsertTraceWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonTrace()));
    connect(InsertDataWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonData()));
    connect(InsertLoggingWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonLog()));
    connect(InsertGraphicsWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonGraphics()));
    connect(Remove,SIGNAL(triggered()),this,SLOT(ClickRemove()));
    i++;
}

void Configuration::contextMenuData(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertStaticWindow = ShowMenu->addAction("InSert Static Window");
    InsertTraceWindow = ShowMenu->addAction("InSert Trace Window");
    InsertDataWindow = ShowMenu->addAction("InSert Data Window");
    InsertLoggingWindow = ShowMenu->addAction("InSert Logging Window");
    InsertGraphicsWindow = ShowMenu->addAction("InSert Graphics Window");

    QPoint globalPos_2 = ButtonData->mapToGlobal(point);
    ShowMenu->popup(globalPos_2);
    ShowMenu->popup(ButtonData->mapToGlobal(point));

    ShowMenu->addSeparator();
    Remove = ShowMenu->addAction("Remove");

    connect(InsertStaticWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonStatic()));
    connect(InsertTraceWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonTrace()));
    connect(InsertDataWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonData()));
    connect(InsertLoggingWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonLog()));
    connect(InsertGraphicsWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonGraphics()));
    connect(Remove,SIGNAL(triggered()),this,SLOT(ClickRemove()));
}

void Configuration::contextMenuDatai(const QPoint &point)
{
    static int i = 0;
    ShowMenu = new QMenu(this);
    InsertStaticWindow = ShowMenu->addAction("InSert Static Window");
    InsertTraceWindow = ShowMenu->addAction("InSert Trace Window");
    InsertDataWindow = ShowMenu->addAction("InSert Data Window");
    InsertLoggingWindow = ShowMenu->addAction("InSert Logging Window");
    InsertGraphicsWindow = ShowMenu->addAction("InSert Graphics Window");

    QPoint globalPos_i = Button[i]->mapToGlobal(point);
    ShowMenu->popup(globalPos_i);
    ShowMenu->popup(Button[i]->mapToGlobal(point));

    ShowMenu->addSeparator();
    Remove = ShowMenu->addAction("Remove");

    connect(InsertStaticWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonStatic()));
    connect(InsertTraceWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonTrace()));
    connect(InsertDataWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonData()));
    connect(InsertLoggingWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonLog()));
    connect(InsertGraphicsWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonGraphics()));
    connect(Remove,SIGNAL(triggered()),this,SLOT(ClickRemove()));
    i++;
}

void Configuration::contextMenuLogging(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertStaticWindow = ShowMenu->addAction("InSert Static Window");
    InsertTraceWindow = ShowMenu->addAction("InSert Trace Window");
    InsertDataWindow = ShowMenu->addAction("InSert Data Window");
    InsertLoggingWindow = ShowMenu->addAction("InSert Logging Window");
    InsertGraphicsWindow = ShowMenu->addAction("InSert Graphics Window");

    QPoint globalPos_4 = ButtonLogging->mapToGlobal(point);
    ShowMenu->popup(globalPos_4);
    ShowMenu->popup(ButtonLogging->mapToGlobal(point));

    ShowMenu->addSeparator();
    Remove = ShowMenu->addAction("Remove");

    connect(InsertStaticWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonStatic()));
    connect(InsertTraceWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonTrace()));
    connect(InsertDataWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonData()));
    connect(InsertLoggingWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonLog()));
    connect(InsertGraphicsWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonGraphics()));
    connect(Remove,SIGNAL(triggered()),this,SLOT(ClickRemove()));
}

void Configuration::contextMenuLoggingi(const QPoint &point)
{
    static int i = 0;
    ShowMenu = new QMenu(this);
    InsertStaticWindow = ShowMenu->addAction("InSert Static Window");
    InsertTraceWindow = ShowMenu->addAction("InSert Trace Window");
    InsertDataWindow = ShowMenu->addAction("InSert Data Window");
    InsertLoggingWindow = ShowMenu->addAction("InSert Logging Window");
    InsertGraphicsWindow = ShowMenu->addAction("InSert Graphics Window");

    QPoint globalPos_i = Button[i]->mapToGlobal(point);
    ShowMenu->popup(globalPos_i);
    ShowMenu->popup(Button[i]->mapToGlobal(point));

    ShowMenu->addSeparator();
    Remove = ShowMenu->addAction("Remove");

    connect(InsertStaticWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonStatic()));
    connect(InsertTraceWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonTrace()));
    connect(InsertDataWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonData()));
    connect(InsertLoggingWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonLog()));
    connect(InsertGraphicsWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonGraphics()));
    connect(Remove,SIGNAL(triggered()),this,SLOT(ClickRemove()));
    i++;
}

void Configuration::contextMenuGraphics(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertStaticWindow = ShowMenu->addAction("InSert Static Window");
    InsertTraceWindow = ShowMenu->addAction("InSert Trace Window");
    InsertDataWindow = ShowMenu->addAction("InSert Data Window");
    InsertLoggingWindow = ShowMenu->addAction("InSert Logging Window");
    InsertGraphicsWindow = ShowMenu->addAction("InSert Graphics Window");

    QPoint globalPos_5 = ButtonGraphics->mapToGlobal(point);
    ShowMenu->popup(globalPos_5);
    ShowMenu->popup(ButtonGraphics->mapToGlobal(point));

    ShowMenu->addSeparator();
    Remove = ShowMenu->addAction("Remove");

    connect(InsertStaticWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonStatic()));
    connect(InsertTraceWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonTrace()));
    connect(InsertDataWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonData()));
    connect(InsertLoggingWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonLog()));
    connect(InsertGraphicsWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonGraphics()));
    connect(Remove,SIGNAL(triggered()),this,SLOT(ClickRemove()));
}

void Configuration::contextMenuGraphicsi(const QPoint &point)
{
    static int i = 0;
    ShowMenu = new QMenu(this);
    InsertStaticWindow = ShowMenu->addAction("InSert Static Window");
    InsertTraceWindow = ShowMenu->addAction("InSert Trace Window");
    InsertDataWindow = ShowMenu->addAction("InSert Data Window");
    InsertLoggingWindow = ShowMenu->addAction("InSert Logging Window");
    InsertGraphicsWindow = ShowMenu->addAction("InSert Graphics Window");

    QPoint globalPos_i = Button[i]->mapToGlobal(point);
    ShowMenu->popup(globalPos_i);
    ShowMenu->popup(Button[i]->mapToGlobal(point));

    ShowMenu->addSeparator();
    Remove = ShowMenu->addAction("Remove");

    connect(InsertStaticWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonStatic()));
    connect(InsertTraceWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonTrace()));
    connect(InsertDataWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonData()));
    connect(InsertLoggingWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonLog()));
    connect(InsertGraphicsWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonGraphics()));
    connect(Remove,SIGNAL(triggered()),this,SLOT(ClickRemove()));
    i++;
}

void Configuration::contextMenuMessage(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertP = ShowMenu->addAction("Insert_P");
    InsertPF = ShowMenu->addAction("Insert_PF");
    InsertR = ShowMenu->addAction("Insert_R");

    ShowMenu->popup(ButtonconnetM3->mapToGlobal(point));

    connect(InsertP,SIGNAL(triggered(bool)),this,SLOT(ClickInsertP()));
    connect(InsertPF,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPF()));
    connect(InsertR,SIGNAL(triggered(bool)),this,SLOT(ClickInsertR()));
}

void Configuration::contextMenuIconBoard(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertP = ShowMenu->addAction("Insert_P");
    InsertPF = ShowMenu->addAction("Insert_PF");
    InsertR = ShowMenu->addAction("Insert_R");

    ShowMenu->popup(ButtonconnetB1->mapToGlobal(point));

    connect(InsertP,SIGNAL(triggered(bool)),this,SLOT(ClickInsertP1()));
    connect(InsertPF,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPF()));
    connect(InsertR,SIGNAL(triggered(bool)),this,SLOT(ClickInsertR()));
}

void Configuration::contextMenuIconStatic(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertP = ShowMenu->addAction("Insert_P");
    InsertPF = ShowMenu->addAction("Insert_PF");
    InsertR = ShowMenu->addAction("Insert_R");

    ShowMenu->popup(ButtonconnetS4->mapToGlobal(point));

    connect(InsertP,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPS()));
    connect(InsertPF,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPF()));
    connect(InsertR,SIGNAL(triggered(bool)),this,SLOT(ClickInsertR()));
}

void Configuration::contextMenuIconStatici(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertP = ShowMenu->addAction("Insert_P");
    InsertPF = ShowMenu->addAction("Insert_PF");
    InsertR = ShowMenu->addAction("Insert_R");

    QPoint globalPos_i = ButtonCN1->mapToGlobal(point);
    ShowMenu->popup(globalPos_i);
    ShowMenu->popup(ButtonCN1->mapToGlobal(point));

    connect(InsertP,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPS()));
    connect(InsertPF,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPF()));
    connect(InsertR,SIGNAL(triggered(bool)),this,SLOT(ClickInsertR()));
}

void Configuration::contextMenuIconData(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertP = ShowMenu->addAction("Insert_P");
    InsertPF = ShowMenu->addAction("Insert_PF");
    InsertR = ShowMenu->addAction("Insert_R");

    ShowMenu->popup(ButtonconnetD6->mapToGlobal(point));

    connect(InsertP,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPD()));
    connect(InsertPF,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPF()));
    connect(InsertR,SIGNAL(triggered(bool)),this,SLOT(ClickInsertR()));
}

void Configuration::contextMenuIconTrace(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertP = ShowMenu->addAction("Insert_P");
    InsertPF = ShowMenu->addAction("Insert_PF");
    InsertR = ShowMenu->addAction("Insert_R");

    ShowMenu->popup(ButtonconnetT5->mapToGlobal(point));

    connect(InsertP,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPT()));
    connect(InsertPF,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPF()));
    connect(InsertR,SIGNAL(triggered(bool)),this,SLOT(ClickInsertR()));
}

void Configuration::contextMenuIconLogging(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertP = ShowMenu->addAction("Insert_P");
    InsertPF = ShowMenu->addAction("Insert_PF");
    InsertR = ShowMenu->addAction("Insert_R");

    ShowMenu->popup(ButtonconnetL7->mapToGlobal(point));

    connect(InsertP,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPL()));
    connect(InsertPF,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPF()));
    connect(InsertR,SIGNAL(triggered(bool)),this,SLOT(ClickInsertR()));
}

void Configuration::contextMenuIconGraphics(const QPoint &point)
{
    ShowMenu = new QMenu(this);
    InsertP = ShowMenu->addAction("Insert_P");
    InsertPF = ShowMenu->addAction("Insert_PF");
    InsertR = ShowMenu->addAction("Insert_R");

    ShowMenu->popup(ButtonconnetG8->mapToGlobal(point));

    connect(InsertP,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPG()));
    connect(InsertPF,SIGNAL(triggered(bool)),this,SLOT(ClickInsertPF()));
    connect(InsertR,SIGNAL(triggered(bool)),this,SLOT(ClickInsertR()));
}


void Configuration::ClickInsertButtonTrace()
{
    static int i =0;
    Button[i] = new QPushButton(tr("Trace %1").arg(i+1));
    Button[i]->setStyleSheet("background-color: rgb(213, 226, 255)");
    Button[i]->setFixedSize(90,50);
    ButtonConnect = new QPushButton;
    ButtonConnect->setFixedSize(20,20);
    ButtonConnect->setStyleSheet("background-color: rgb(82, 105, 255)");
    HB_layout = new QHBoxLayout;
    HB_layout->addWidget(ButtonConnect);
    HB_layout->addWidget(Button[i]);
    V_Layout->addLayout(HB_layout);

    Button[i]->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(Button[i],SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuTracei(QPoint)));

    ButtonConnect->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonConnect,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconTrace(QPoint)));
    i++;
}

void Configuration::ClickInsertButtonData()
{
    static int i =0;
    Button[i] = new QPushButton(tr("Data %1").arg(i+1));
    Button[i]->setStyleSheet("background-color: rgb(213, 226, 255)");
    Button[i]->setFixedSize(90,50);
    ButtonConnect = new QPushButton;
    ButtonConnect->setFixedSize(20,20);
    ButtonConnect->setStyleSheet("background-color: rgb(82, 105, 255)");
    HB_layout = new QHBoxLayout;
    HB_layout->addWidget(ButtonConnect);
    HB_layout->addWidget(Button[i]);
    V_Layout->addLayout(HB_layout);

    Button[i]->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(Button[i],SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuDatai(QPoint)));

    ButtonConnect->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonConnect,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconDatai(QPoint)));
    i++;
}

void Configuration::ClickInsertButtonLog()
{
    static int i =0;
    Button[i] = new QPushButton(tr("Logging %1").arg(i+1));
    Button[i]->setStyleSheet("background-color: rgb(213, 226, 255)");
    Button[i]->setFixedSize(90,50);
    ButtonConnect = new QPushButton;
    ButtonConnect->setFixedSize(20,20);
    ButtonConnect->setStyleSheet("background-color: rgb(82, 105, 255)");
    HB_layout = new QHBoxLayout;
    HB_layout->addWidget(ButtonConnect);
    HB_layout->addWidget(Button[i]);
    V_Layout->addLayout(HB_layout);
    Button[i]->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(Button[i],SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuLoggingi(QPoint)));

    ButtonConnect->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonConnect,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconLogging(QPoint)));
    i++;
}

void Configuration::ClickInsertButtonStatic()
{
    static int i =0;
    Button[i] = new QPushButton(tr("Static %1").arg(i+1));
    Button[i]->setStyleSheet("background-color: rgb(213, 226, 255)");
    Button[i]->setFixedSize(90,50);
    ButtonConnect = new QPushButton;
    ButtonConnect->setFixedSize(20,20);
    ButtonConnect->setStyleSheet("background-color: rgb(82, 105, 255)");
    HB_layout = new QHBoxLayout;
    HB_layout->addWidget(ButtonConnect);
    HB_layout->addWidget(Button[i]);
    V_Layout->addLayout(HB_layout);
    Button[i]->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(Button[i],SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuStatici(QPoint)));

    ButtonConnect->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonConnect,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconStatic(QPoint)));
    i++;
}

void Configuration::ClickInsertButtonGraphics()
{
    static int i =0;
    Button[i] = new QPushButton(tr("Graphics %1").arg(i+1));
    Button[i]->setStyleSheet("background-color: rgb(213, 226, 255)");
    Button[i]->setFixedSize(90,50);
    ButtonConnect = new QPushButton;
    ButtonConnect->setFixedSize(20,20);
    ButtonConnect->setStyleSheet("background-color: rgb(82, 105, 255)");
    HB_layout = new QHBoxLayout;
    HB_layout->addWidget(ButtonConnect);
    HB_layout->addWidget(Button[i]);
    V_Layout->addLayout(HB_layout);
    Button[i]->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(Button[i],SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuGraphicsi(QPoint)));

    ButtonConnect->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonConnect,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconGraphics(QPoint)));
    i++;
}

void Configuration::ClickInsertP()
{
    ButtonP = new QPushButton("P");
    ButtonP->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonP->setFixedSize(45,45);
    ButtonCN1 = new QPushButton;
    ButtonCN1->setStyleSheet("background-color: rgb(82, 105, 255)");
    ButtonCN1->setFixedSize(20,20);
    V3_Layout->addWidget(ButtonP,2);
    V3_Layout->addWidget(ButtonCN1,3);
    ButtonCN1->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonCN1,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuMessage(QPoint)));
}

void Configuration::ClickInsertP1()
{
    ButtonP = new QPushButton("P");
    ButtonP->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonP->setFixedSize(45,45);
    ButtonCN1 = new QPushButton;
    ButtonCN1->setStyleSheet("background-color: rgb(82, 105, 255)");

    H1_Layout->addWidget(ButtonP);
    H1_Layout->addWidget(ButtonCN1);


    ButtonCN1->setFixedSize(20,20);
    ButtonCN1->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonCN1,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuMessage(QPoint)));
}

void Configuration::ClickInsertPS()
{
    ButtonP = new QPushButton("P");
    ButtonP->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonP->setFixedSize(45,45);
    ButtonCN1 = new QPushButton;
    ButtonCN1->setStyleSheet("background-color: rgb(82, 105, 255)");
    H4_Layout->addWidget(ButtonP);
    H4_Layout->addWidget(ButtonCN1);
    ButtonCN1->setFixedSize(20,20);
    ButtonCN1->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonCN1,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconStatici(QPoint)));
}


void Configuration::ClickInsertPD()
{
    ButtonP = new QPushButton("P");
    ButtonP->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonP->setFixedSize(45,45);
    ButtonCN1 = new QPushButton;
    ButtonCN1->setStyleSheet("background-color: rgb(82, 105, 255)");
    H6_Layout->addWidget(ButtonP);
    H6_Layout->addWidget(ButtonCN1);
    ButtonCN1->setFixedSize(20,20);
    ButtonCN1->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonCN1,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconStatici(QPoint)));
}

void Configuration::ClickInsertPT()
{
    ButtonP = new QPushButton("P");
    ButtonP->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonP->setFixedSize(45,45);
    ButtonCN1 = new QPushButton;
    ButtonCN1->setStyleSheet("background-color: rgb(82, 105, 255)");
    H5_Layout->addWidget(ButtonP);
    H5_Layout->addWidget(ButtonCN1);
    ButtonCN1->setFixedSize(20,20);
    ButtonCN1->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonCN1,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconStatici(QPoint)));
}

void Configuration::ClickInsertPL()
{
    ButtonP = new QPushButton("P");
    ButtonP->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonP->setFixedSize(45,45);
    ButtonCN1 = new QPushButton;
    ButtonCN1->setStyleSheet("background-color: rgb(82, 105, 255)");
    H7_Layout->addWidget(ButtonP);
    H7_Layout->addWidget(ButtonCN1);
    ButtonCN1->setFixedSize(20,20);
    ButtonCN1->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonCN1,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconStatici(QPoint)));
}

void Configuration::ClickInsertPG()
{
    ButtonP = new QPushButton("P");
    ButtonP->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonP->setFixedSize(45,45);
    ButtonCN1 = new QPushButton;
    ButtonCN1->setStyleSheet("background-color: rgb(82, 105, 255)");
    H8_Layout->addWidget(ButtonP);
    H8_Layout->addWidget(ButtonCN1);
    ButtonCN1->setFixedSize(20,20);
    ButtonCN1->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonCN1,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconStatici(QPoint)));
}

void Configuration::ClickInsertPF()
{
    QPushButton *ButtonPF = new QPushButton("PF");
    ButtonPF->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonPF->setFixedSize(45,45);
    QPushButton *ButtonCNPF = new QPushButton;
    ButtonCNPF->setStyleSheet("background-color: rgb(82, 105, 255)");
    ButtonCNPF->setFixedSize(20,20);
    H1_Layout->addWidget(ButtonPF);
    H1_Layout->addWidget(ButtonCNPF);
    ButtonCNPF->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonCNPF,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuIconStatici(QPoint)));

}

void Configuration::ClickInsertR()
{
    ButtonP = new QPushButton("R");
    ButtonP->setStyleSheet("background-color: rgb(213, 226, 255)");
    ButtonP->setFixedSize(45,45);
    ButtonCN1 = new QPushButton;
    ButtonCN1->setStyleSheet("background-color: rgb(82, 105, 255)");


    H1_Layout->addWidget(ButtonP);
    H1_Layout->addWidget(ButtonCN1);
    ButtonCN1->setFixedSize(20,20);
    ButtonCN1->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonCN1,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuMessage(QPoint)));
}

void Configuration::ClickRemove()
{
    int i = 0;
    //HB_layout = new QHBoxLayout;
    //HB_layout->addWidget(ButtonConnect);
    HB_layout->removeWidget(ButtonConnect);
   // HB_layout->addWidget(Button[i]);
    HB_layout->removeWidget(Button[i]);

    V_Layout->addLayout(HB_layout);
    i++;


}
