#include "cfmainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    CFMainWindow w;
    w.setWindowTitle("Configuration");
    w.setWindowIcon(QPixmap(":icon/icon/FPT_T.png"));
    w.show();

    return a.exec();
}
