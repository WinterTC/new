#include "fixedmainwindow.h"
#include "ui_fixedmainwindow.h"

FixedMainWindow::FixedMainWindow(QWidget *parent) :
    QMainWindow(parent)
{
    setupUi(this);
    remove->setCheckable(false);
    remove->setChecked(false);
    connect(remove,SIGNAL(clicked(bool)),Logging,SLOT(setEnabled(bool)));
    connect(remove,SIGNAL(clicked(bool)),PF1,SLOT(setEnabled(bool)));
    connect(remove,SIGNAL(clicked(bool)),pushButton_25,SLOT(setEnabled(bool)));
}

FixedMainWindow::~FixedMainWindow()
{

}

void FixedMainWindow::paintEvent(QPaintEvent *event)
{
    QPainter Painter(this);
    QPen Linepen(Qt::gray);
    Linepen.setWidth(2);
    Painter.setPen(Linepen);
    QPoint P1;
    P1.setX(50);
    P1.setY(280);

    QPoint P21;
    P21.setX(310);
    P21.setY(270);
    QPoint P22;
    P22.setX(310);
    P22.setY(290);
    QPoint P23;
    P23.setX(320);
    P23.setY(280);
    Painter.drawLine(P21,P22);
    Painter.drawLine(P21,P23);
    Painter.drawLine(P22,P23);

    QPoint P24;
    P24.setX(360);
    P24.setY(270);
    QPoint P25;
    P25.setX(360);
    P25.setY(290);
    QPoint P26;
    P26.setX(370);
    P26.setY(280);
    Painter.drawLine(P24,P25);
    Painter.drawLine(P24,P26);
    Painter.drawLine(P25,P26);

    QPoint P51;
    P51.setX(330);
    P51.setY(300);
    QPoint P52;
    P52.setX(350);
    P52.setY(300);
    QPoint P53;
    P53.setX(340);
    P53.setY(315);
    Painter.drawLine(P51,P52);
    Painter.drawLine(P52,P53);
    Painter.drawLine(P53,P51);

    QPoint P27;
    P27.setX(310);
    P27.setY(670);
    QPoint P28;
    P28.setX(310);
    P28.setY(690);
    QPoint P29;
    P29.setX(300);
    P29.setY(680);
    Painter.drawLine(P27,P28);
    Painter.drawLine(P28,P29);
    Painter.drawLine(P29,P27);


    QPoint P2;// re nhanh
    P2.setX(340);
    P2.setY(280);
    Painter.drawLine(P1,P2);

    QPoint P3;//re nhanh
    P3.setX(530);
    P3.setY(280);
    Painter.drawLine(P2,P3);

    QPoint P4;
    P4.setX(710);
    P4.setY(280);
    Painter.drawLine(P3,P4);

    QPoint P5;
    P5.setX(530);
    P5.setY(210);
    Painter.drawLine(P3,P5);

    QPoint P6;
    P6.setX(710);
    P6.setY(210);
    Painter.drawLine(P5,P6);

    QPoint P7;
    P7.setX(530);
    P7.setY(140);
    Painter.drawLine(P5,P7);

    QPoint P8;
    P8.setX(710);
    P8.setY(140);
    Painter.drawLine(P7,P8);

    QPoint P9;
    P9.setX(530);
    P9.setY(70);
    Painter.drawLine(P7,P9);

    QPoint P10;
    P10.setX(710);
    P10.setY(70);
    Painter.drawLine(P9,P10);

    QPoint P31;
    P31.setX(530);
    P31.setY(350);
    Painter.drawLine(P3,P31);

    QPoint P32;
    P32.setX(710);
    P32.setY(350);
    Painter.drawLine(P31,P32);

    QPoint P33;
    P33.setX(530);
    P33.setY(420);
    Painter.drawLine(P31,P33);

    QPoint P34;
    P34.setX(710);
    P34.setY(420);
    Painter.drawLine(P33,P34);

    QPoint P35;
    P35.setX(530);
    P35.setY(490);
    Painter.drawLine(P33,P35);

    QPoint P36;
    P36.setX(710);
    P36.setY(490);
    Painter.drawLine(P35,P36);

    QPoint P11;
    P11.setX(340);
    P11.setY(680);
    Painter.drawLine(P2,P11);

    QPoint P12;
    P12.setX(50);
    P12.setY(680);
    Painter.drawLine(P11,P12);
    Painter.drawLine(P12,P1);

//    int with = ui->Button1->width();
//    int height = ui->Button1->height();
//    int x = ui->Button1->x();
//    int y = ui->Button1->y();

//    int with1 = ui->Button2->width();
//    int height1 = ui->Button2->height();
//    int x1 = ui->Button2->x();
//    int y1 = ui->Button2->y();
    //Painter.translate(0,55);

//    QPoint p(Button3->x()+Button3->width()/2,Button3->y()+55+Button3->height()/2);
//    QPoint p1(Button2->x()+Button2->width()/2,Button2->y()+55+Button2->height()/2);
//    Painter.drawLine(x + with/2,y+height/2,x1+with1/2,y1+height1/2);
    //Painter.drawLine(ui->Button1->x()+ui->Button1->width()/2,ui->Button1->y()+ui->Button1->height()/2,);
//    Painter.drawLine(p1,p);
    event->accept();
}
