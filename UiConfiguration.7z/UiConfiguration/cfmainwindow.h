#ifndef CFMAINWINDOW_H
#define CFMAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class CFMainWindow;
}

class CFMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit CFMainWindow(QWidget *parent = 0);
    ~CFMainWindow();

private slots:
    void on_action_New_triggered();

private:
    Ui::CFMainWindow *ui;
    void loadSubWindow(QWidget *widget);
};

#endif // CFMAINWINDOW_H
