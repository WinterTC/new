#ifndef FIXEDMAINWINDOW_H
#define FIXEDMAINWINDOW_H

#include <QMainWindow>
#include "QtWidgets"
#include "QtCore"
#include "QtGui"
#include "QModelIndex"
#include "ui_fixedmainwindow.h"

namespace Ui {
class FixedMainWindow;
}

class FixedMainWindow : public QMainWindow,Ui_FixedMainWindow
{
    Q_OBJECT

public:
    explicit FixedMainWindow(QWidget *parent = 0);
    ~FixedMainWindow();
protected:
    void paintEvent(QPaintEvent *event);

private:

};

#endif // FIXEDMAINWINDOW_H
