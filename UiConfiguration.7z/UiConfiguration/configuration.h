#ifndef CONFIGURATION_H
#define CONFIGURATION_H

#include <QMainWindow>
#include "QtGui"
#include "QtWidgets"
#include "QtCore"

namespace Ui {
class Configuration;
}

class Configuration : public QMainWindow
{
    Q_OBJECT

public:
    explicit Configuration(QWidget *parent = 0);
    ~Configuration();
protected:
    void paintEvent(QPaintEvent *event);

private slots:
    void contextMenuConnect(const QPoint& point);

    void contextMenuStatic(const QPoint& point);
    void contextMenuStatici(const QPoint& point);
    void contextMenuTrace(const QPoint& point);
    void contextMenuTracei(const QPoint& point);
    void contextMenuData(const QPoint& point);
    void contextMenuDatai(const QPoint& point);
    void contextMenuLogging(const QPoint& point);
    void contextMenuLoggingi(const QPoint& point);
    void contextMenuGraphics(const QPoint& point);
    void contextMenuGraphicsi(const QPoint& point);

    void contextMenuMessage(const QPoint &point);

    void contextMenuIconBoard(const QPoint& point);

    void contextMenuIconStatic(const QPoint& point);
    void contextMenuIconStatici(const QPoint& point);
    void contextMenuIconData(const QPoint& point);
    void contextMenuIconTrace(const QPoint& point);
    void contextMenuIconLogging(const QPoint& point);
    void contextMenuIconGraphics(const QPoint& point);


    void ClickInsertButtonTrace();
    void ClickInsertButtonData();
    void ClickInsertButtonLog();
    void ClickInsertButtonStatic();
    void ClickInsertButtonGraphics();
    void ClickInsertP();
    void ClickInsertP1();

    void ClickInsertPS();
    void ClickInsertPD();
    void ClickInsertPT();
    void ClickInsertPL();
    void ClickInsertPG();

    void ClickInsertPF();
    void ClickInsertR();
    void ClickRemove();

private:
    Ui::Configuration *ui;
    QMenu *ShowMenu;
    QLayout *Layout;
    QWidget *Widget;
    QGridLayout *G_Layout;
    QHBoxLayout *H1_Layout,*H2_Layout,*H4_Layout,*H5_Layout,*H6_Layout,*H7_Layout,*H8_Layout;
    QHBoxLayout *HB_layout;
    QVBoxLayout *V_Layout,*V3_Layout;

    QPushButton *ButtonBoard,*ButtonconnetB1;
    QPushButton *Buttonconnet2;
    QPushButton *ButtonconnetM3,*ButtonMessage;
    QPushButton *ButtonconnetS4,*ButtonStatic;
    QPushButton *ButtonconnetT5,*ButtonTrace;
    QPushButton *ButtonconnetD6,*ButtonData;
    QPushButton *ButtonconnetL7,*ButtonLogging;
    QPushButton *ButtonconnetG8,*ButtonGraphics;
    QPushButton *ButtonP,*ButtonCN1;
    QPushButton *Button[100],*ButtonConnect;

    QAction *InsertStaticWindow;
    QAction *InsertTraceWindow;
    QAction *InsertDataWindow;
    QAction *InsertLoggingWindow;
    QAction *InsertGraphicsWindow;
    QAction *InsertP,*InsertPF,*InsertR;
    QAction *Remove;
};

#endif // CONFIGURATION_H
